class Producto:
    def __init__(self, nombre, descripcion, precio, cantidad_stock, categoria):
        self.nombre = nombre
        self.descripcion = descripcion
        self.precio = precio
        self.cantidad_stock = cantidad_stock
        self.categoria = categoria

    def insertar_producto(self):
        print(f"Producto {self.nombre} agregado al inventario.")

    def editar_producto(self, nuevo_nombre=None, nuevo_precio=None):
        if nuevo_nombre:
            self.nombre = nuevo_nombre
        if nuevo_precio:
            self.precio = nuevo_precio
        print(f"Producto actualizado: {self.nombre}, Precio: {self.precio}")

    def eliminar_producto(self):
        print(f"Producto {self.nombre} eliminado del inventario.")

    def ver_detalles(self):
        print(f"Nombre: {self.nombre}, Precio: {self.precio}, Stock: {self.cantidad_stock}")
