class Venta:
    def __init__(self, productos_vendidos, cliente, fecha):
        self.productos_vendidos = productos_vendidos
        self.cliente = cliente
        self.fecha = fecha

    def registrar_venta(self, inventario):
        for producto_vendido in self.productos_vendidos:
            inventario.actualizar_cantidad_stock(producto_vendido.nombre, producto_vendido.cantidad_stock - 1)
        print(f"Venta registrada para {self.cliente} en la fecha {self.fecha}.")

    def generar_factura(self):
        print(f"Factura generada para {self.cliente}.")
