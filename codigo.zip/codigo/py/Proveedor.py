class Proveedor:
    def __init__(self, nombre, direccion, telefono):
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono

    def agregar_proveedor(self):
        print(f"Proveedor {self.nombre} agregado.")

    def editar_proveedor(self, nuevo_nombre=None, nueva_direccion=None, nuevo_telefono=None):
        if nuevo_nombre:
            self.nombre = nuevo_nombre
        if nueva_direccion:
            self.direccion = nueva_direccion
        if nuevo_telefono:
            self.telefono = nuevo_telefono
        print(f"Proveedor actualizado: {self.nombre}")

    def eliminar_proveedor(self):
        print(f"Proveedor {self.nombre} eliminado.")
