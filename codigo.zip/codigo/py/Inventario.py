class Inventario:
    def __init__(self):
        self.productos = []

    def agregar_producto(self, producto):
        self.productos.append(producto)
        print(f"Producto {producto.nombre} agregado al inventario.")

    def actualizar_cantidad_stock(self, nombre_producto, nueva_cantidad):
        for producto in self.productos:
            if producto.nombre == nombre_producto:
                producto.cantidad_stock = nueva_cantidad
                print(f"Stock de {nombre_producto} actualizado a {nueva_cantidad}.")
                return
        print("Producto no encontrado.")

    def mostrar_inventario(self):
        print("Inventario:")
        for producto in self.productos:
            producto.ver_detalles()
