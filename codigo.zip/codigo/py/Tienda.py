import mysql.connector

def conectar_bd():
    try:
        conexion = mysql.connector.connect(
            host="localhost",
            user="root",        # Cambia por tu usuario de MySQL
            password="",        # Introduce tu contraseña si la configuraste
            database="TiendaInsumosComputacionales"
        )
        return conexion
    except mysql.connector.Error as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None
