class Reporte:
    def __init__(self, inventario):
        self.inventario = inventario

    def generar_reporte_inventario(self):
        print("----- Reporte de Inventario -----")
        for producto in self.inventario.productos:
            producto.ver_detalles()

    def productos_mas_vendidos(self):
        print("Análisis de productos más vendidos: (función a implementar)")
