const productosSelect = document.getElementById('productosSeleccionados');
const productosCantidadDiv = document.getElementById('productosCantidad');

productosSelect.addEventListener('change', () => {
    productosCantidadDiv.innerHTML = ''; // Limpia las cantidades previas

    Array.from(productosSelect.selectedOptions).forEach(option => {
        const div = document.createElement('div');
        div.innerHTML = `
            <label>${option.text}:</label>
            <input type="number" name="cantidad_${option.value}" min="1" max="${option.dataset.stock}" required>
        `;
        productosCantidadDiv.appendChild(div);
    });
});
