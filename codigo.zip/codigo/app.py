from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
from flask import send_file

import matplotlib.pyplot as plt
app = Flask(__name__)

# Conexión a la base de datos
def conectar_bd():
    return mysql.connector.connect(
        host="localhost",
        user="root",  # Cambia por tu usuario de MySQL
        password="",  # Introduce tu contraseña si la configuraste
        database="tiendaonlinecomponents"
    )

@app.route('/')
def index():
    return render_template('Tienda.html')
# Ruta principal




# Mostrar Inventario
@app.route('/inventario')
def inventario():
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM Producto")
    productos = cursor.fetchall()
    conexion.close()
    return render_template('inventario.html', productos=productos)
@app.route('/agregar_producto', methods=['POST'])
def agregar_producto():
    try:
        # Validar que precio y cantidadStock sean numéricos
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        
        # Validar precio (debe ser un número decimal)
        try:
            precio = float(request.form['precio'])
        except ValueError:
            return "El precio debe ser un valor numérico.", 400

        # Validar cantidadStock (debe ser un número entero)
        try:
            cantidad_stock = int(request.form['cantidadStock'])
        except ValueError:
            return "La cantidad en stock debe ser un valor numérico entero.", 400
        
        categoria = request.form['categoria']
        
        # Inserción a la base de datos
        conexion = conectar_bd()
        cursor = conexion.cursor()
        consulta = """
        INSERT INTO Producto (nombre, descripcion, precio, cantidadStock, categoria)
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(consulta, (nombre, descripcion, precio, cantidad_stock, categoria))
        conexion.commit()
        conexion.close()

        return redirect(url_for('inventario'))
    except Exception as e:
        return f"Error al agregar el producto: {str(e)}", 500


@app.route('/eliminar_producto/<int:id_producto>', methods=['POST'])
def eliminar_producto(id_producto):
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()

        # Verificar si el producto tiene relaciones en 'detalleventa'
        cursor.execute("SELECT COUNT(*) FROM detalleventa WHERE idProducto = %s", (id_producto,))
        relaciones = cursor.fetchone()[0]

        if relaciones > 0:
            # Si existen registros relacionados, manejarlos (por ejemplo, eliminarlos)
            cursor.execute("DELETE FROM detalleventa WHERE idProducto = %s", (id_producto,))

        # Ahora eliminar el producto
        cursor.execute("DELETE FROM Producto WHERE idProducto = %s", (id_producto,))
        
        conexion.commit()
        conexion.close()

        return redirect(url_for('inventario'))
    except Exception as e:
        conexion.rollback()
        conexion.close()
        return f"Error al eliminar el producto: {e}", 500


# Editar Producto (Mostrar formulario)
@app.route('/editar_producto/<int:id_producto>', methods=['GET'])
def editar_producto(id_producto):
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM Producto WHERE idProducto = %s", (id_producto,))
    producto = cursor.fetchone()
    conexion.close()
    return render_template('editar_producto.html', producto=producto)

# Actualizar Producto
@app.route('/actualizar_producto/<int:id_producto>', methods=['POST'])
def actualizar_producto(id_producto):
    nombre = request.form['nombre']
    descripcion = request.form['descripcion']
    precio = float(request.form['precio'])
    cantidad_stock = int(request.form['cantidadStock'])
    categoria = request.form['categoria']

    conexion = conectar_bd()
    cursor = conexion.cursor()
    consulta = """
    UPDATE Producto
    SET nombre = %s, descripcion = %s, precio = %s, cantidadStock = %s, categoria = %s
    WHERE idProducto = %s
    """
    cursor.execute(consulta, (nombre, descripcion, precio, cantidad_stock, categoria, id_producto))
    conexion.commit()
    conexion.close()
    return redirect(url_for('inventario'))

# Ver Producto
@app.route('/ver_producto/<int:id_producto>', methods=['GET'])
def ver_producto(id_producto):
    conexion = conectar_bd()
    cursor = conexion.cursor()
    # Consulta para obtener los datos del producto por ID
    cursor.execute("SELECT * FROM Producto WHERE idProducto = %s", (id_producto,))
    producto = cursor.fetchone()
    conexion.close()
    return render_template('ver_producto.html', producto=producto)

@app.route('/ventas', methods=['GET', 'POST'])
def ventas():
    conexion = conectar_bd()
    cursor = conexion.cursor()

    if request.method == 'POST':
        cliente = request.form['cliente']
        fecha = request.form['fecha']
        total = float(request.form['total'])
        productos_seleccionados = request.form.getlist('productos')  # Obtiene los productos seleccionados

        if not productos_seleccionados:
            return render_template('ventas.html', error="Debe seleccionar al menos un producto.")

        # Insertar la venta en la tabla `Venta`
        cursor.execute(
            "INSERT INTO Venta (fecha, cliente, total) VALUES (%s, %s, %s)",
            (fecha, cliente, total)
        )
        id_venta = cursor.lastrowid  # Obtiene el ID de la venta recién insertada

        # Registrar los productos vendidos y actualizar el inventario
        for producto_id in productos_seleccionados:
            # Validar la cantidad vendida
            cantidad_vendida = int(request.form.get(f'cantidad_{producto_id}', 0))  # Evitar errores si no existe
            if cantidad_vendida <= 0:
                continue  # Saltar productos con cantidad no válida

            # Insertar en la tabla `DetalleVenta`
            cursor.execute(
                "INSERT INTO DetalleVenta (idVenta, idProducto, cantidad) VALUES (%s, %s, %s)",
                (id_venta, producto_id, cantidad_vendida)
            )

            # Actualizar el stock del producto en la tabla `Producto`
            cursor.execute(
                "UPDATE Producto SET cantidadStock = GREATEST(cantidadStock - %s, 0) WHERE idProducto = %s",
                (cantidad_vendida, producto_id)
            )

        conexion.commit()
        conexion.close()

        return redirect(url_for('ventas'))



    # Obtener productos para mostrarlos en el formulario
    cursor.execute("SELECT idProducto, nombre, descripcion, cantidadStock, categoria FROM Producto")
    productos = cursor.fetchall()
    conexion.close()

    return render_template('ventas.html', productos=productos)





# Detalle de Venta (Generar Factura)
@app.route('/detalleventa')
def detalleventa():
    return render_template('detalleventa.html')  # Asegúrate de que el archivo sea "detalleventa.html"
@app.route('/detalleventa/<int:idVenta>')
def detalle_venta(id_Venta):
    conexion = conectar_bd()
    cursor = conexion.cursor()

    # Obtener datos generales de la venta
    cursor.execute("SELECT cliente, fecha, total FROM Venta WHERE idVenta = %s", (id_Venta,))
    venta = cursor.fetchone()
 
    if not venta:
        return f"No se encontró ninguna venta con ID {id_Venta}", 404



    # Obtener datos generales de la venta
    cursor.execute("SELECT cliente, fecha, total FROM Venta WHERE idVenta = %s", (id_Venta,))
    venta = cursor.fetchone()


from flask import render_template


   
    # Renderiza la plantilla con los datos

@app.route('/reporte_ingresos')
def reporte_ingresos():
    conexion = conectar_bd()
    cursor = conexion.cursor()

    # Ejecuta la consulta de ingresos
    cursor.execute("""
        SELECT Producto.nombre, SUM(DetalleVenta.cantidad * DetalleVenta.precioUnitario) AS ingresos_totales
        FROM DetalleVenta
        INNER JOIN Producto ON DetalleVenta.idProducto = Producto.idProducto
        GROUP BY Producto.idProducto
        ORDER BY ingresos_totales DESC
        LIMIT 10;
    """)
    productos = cursor.fetchall()
    conexion.close()

    return render_template('reporte_ingresos.html', productos=productos)


@app.route('/reporte_central')
def reporte_central():
    conexion = conectar_bd()
    cursor = conexion.cursor()

    # Consultar productos con bajo inventario
    cursor.execute("""
        SELECT idProducto, nombre, descripcion, cantidadStock, categoria 
        FROM producto 
        WHERE cantidadStock < 10;
    """)
    inventario_minimo = cursor.fetchall()

    # Consultar productos más vendidos
    cursor.execute("""
        SELECT Producto.nombre, SUM(DetalleVenta.cantidad) AS total_vendido
        FROM DetalleVenta
        INNER JOIN Producto ON DetalleVenta.idProducto = Producto.idProducto
        GROUP BY Producto.idProducto
        ORDER BY total_vendido DESC
        LIMIT 10;
    """)
    mas_vendidos = cursor.fetchall()

    # Consultar productos menos vendidos
    cursor.execute("""
        SELECT Producto.nombre, SUM(DetalleVenta.cantidad) AS total_vendido
        FROM DetalleVenta
        INNER JOIN Producto ON DetalleVenta.idProducto = Producto.idProducto
        GROUP BY Producto.idProducto
        ORDER BY total_vendido ASC
        LIMIT 10;
    """)
    menos_vendidos = cursor.fetchall()

    conexion.close()

    # Generar gráficas
    generar_grafica(
        mas_vendidos,
        'static/mas_vendidos.png',
        'Productos Más Vendidos',
        'Ventas'
    )
    generar_grafica(
        menos_vendidos,
        'static/menos_vendidos.png',
        'Productos Menos Vendidos',
        'Ventas'
    )
    generar_grafica(
        [(fila[1], fila[3]) for fila in inventario_minimo],
        'static/inventario_minimo.png',
        'Inventario Bajo',
        'Stock'
    )

    return render_template(
        'reporte_central.html',
        inventario_minimo=inventario_minimo,
        mas_vendidos=mas_vendidos,
        menos_vendidos=menos_vendidos
    )


def generar_grafica(data, filename, title, ylabel):
    nombres = [fila[0] for fila in data]
    valores = [int(fila[1] or 0) for fila in data]

    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 6))
    plt.plot(nombres, valores, marker='o', color='b')
    plt.xlabel('Productos')
    plt.ylabel(ylabel)
    plt.title(title)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()


@app.route('/exportar_reporte', methods=['GET'])
def exportar_reporte():
    conexion = conectar_bd()  # Conexión a la base de datos
    cursor = conexion.cursor()

    # Consultar los datos de la tabla 'producto'
    cursor.execute("""
        SELECT idProducto, nombre, descripcion, cantidadStock, categoria 
        FROM producto;
    """)
    resultados = cursor.fetchall()  # Obtener todos los resultados

    # Crear y escribir el archivo CSV manualmente
    archivo_csv = "reporte.csv"
    with open(archivo_csv, 'w', encoding='utf-8') as archivo:
        # Escribir encabezados
        archivo.write("ID Producto,Nombre,Descripción,Cantidad Stock,Categoría\n")

        # Escribir filas
        for fila in resultados:
            archivo.write(",".join([str(campo) for campo in fila]) + "\n")

    conexion.close()

    # Enviar el archivo al cliente
    return send_file(archivo_csv, as_attachment=True, download_name="reporte.csv")
@app.route('/importar_reporte', methods=['POST'])
def importar_reporte():
    archivo = request.files.get('archivo')  # Archivo subido por el cliente

    if not archivo or archivo.filename == '':
        return "Por favor, selecciona un archivo válido.", 400

    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()

        # Leer el archivo línea por línea
        for index, linea in enumerate(archivo):
            if index == 0:  # Omitir la primera línea (encabezados)
                continue

            datos = linea.decode('utf-8').strip().split(",")  # Dividir por comas

            # Insertar en la base de datos
            cursor.execute("""
                INSERT INTO producto (idProducto, nombre, descripcion, cantidadStock, categoria)
                VALUES (%s, %s, %s, %s, %s)
            """, datos)

        conexion.commit()
        conexion.close()
        return "Datos importados correctamente."
    except Exception as e:
        return f"Ocurrió un error al importar los datos: {str(e)}", 500

   
# Mostrar Proveedores
@app.route('/proveedores')
def proveedores():
    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM Proveedor")
    proveedores = cursor.fetchall()
    conexion.close()
    print(proveedores)  # Depurar para verificar los datos
    return render_template('proveedores.html', proveedores=proveedores)

@app.route('/asociar_producto_proveedor', methods=['POST'])
def asociar_producto_proveedor():
    try:
        id_producto = request.form['id_producto']
        id_proveedor = request.form['id_proveedor']
        
        # Validar que ambos IDs sean válidos
        if not id_producto or not id_proveedor:
            return "Por favor, ingrese ambos IDs.", 400
        
        conexion = conectar_bd()
        cursor = conexion.cursor()
        
        # Verificar que el producto existe
        cursor.execute("SELECT idProducto FROM Producto WHERE idProducto = %s", (id_producto,))
        producto = cursor.fetchone()
        if not producto:
            return "El producto no existe.", 400

        # Verificar que el proveedor existe
        cursor.execute("SELECT idProveedor FROM Proveedor WHERE idProveedor = %s", (id_proveedor,))
        proveedor = cursor.fetchone()
        if not proveedor:
            return "El proveedor no existe.", 400

        # Asociar producto y proveedor
        consulta = """
        INSERT INTO ProductoProveedor (idProducto, idProveedor)
        VALUES (%s, %s)
        """
        cursor.execute(consulta, (id_producto, id_proveedor))
        conexion.commit()
        conexion.close()
        
        return redirect(url_for('proveedores'))
    except Exception as e:
        return f"Error al asociar producto con proveedor: {str(e)}", 500
@app.route('/asociaciones')
def asociaciones():
    conexion = conectar_bd()
    cursor = conexion.cursor()
    
    # Consultar todas las asociaciones
    cursor.execute("""
        SELECT pp.idProducto, p.nombre AS producto, pp.idProveedor, pr.nombre AS proveedor
        FROM ProductoProveedor AS pp
        INNER JOIN Producto AS p ON pp.idProducto = p.idProducto
        INNER JOIN Proveedor AS pr ON pp.idProveedor = pr.idProveedor
    """)
    asociaciones = cursor.fetchall()
    conexion.close()

    return render_template('asociaciones.html', asociaciones=asociaciones)



@app.route('/agregar_proveedor', methods=['POST'])
def agregar_proveedor():
    try:
        nombre = request.form['nombre']
        direccion = request.form['direccion']
        telefono = request.form['telefono']

        # Validar que los campos no estén vacíos
        if not nombre or not direccion or not telefono:
            return "Por favor, completa todos los campos.", 400

        conexion = conectar_bd()
        cursor = conexion.cursor()
        consulta = """
        INSERT INTO Proveedor (nombre, direccion, telefono)
        VALUES (%s, %s, %s)
        """
        cursor.execute(consulta, (nombre, direccion, telefono))
        conexion.commit()
        conexion.close()
        return redirect(url_for('proveedores'))
    except Exception as e:
        return f"Error al agregar el proveedor: {str(e)}", 500


@app.route('/editar_proveedor/<int:id_proveedor>', methods=['GET'])
def editar_proveedor(id_proveedor):
    conexion = conectar_bd()
    cursor = conexion.cursor()
    
    # Consulta para obtener el proveedor por ID
    cursor.execute("SELECT * FROM Proveedor WHERE idProveedor = %s", (id_proveedor,))
    proveedor_data = cursor.fetchone()  # Devuelve una tupla
    conexion.close()

    # Si no se encuentra el proveedor, maneja el caso
    if not proveedor_data:
        return f"No se encontró un proveedor con ID {id_proveedor}", 404

    # Convertir los datos en un diccionario
    proveedor = {
        'idProveedor': proveedor_data[0],
        'nombre': proveedor_data[1],
        'direccion': proveedor_data[2],
        'telefono': proveedor_data[3]
    }

    return render_template('editar_proveedor.html', proveedor=proveedor)



# Actualizar Proveedor
@app.route('/actualizar_proveedor/<int:id_proveedor>', methods=['POST'])
def actualizar_proveedor(id_proveedor):
    nombre = request.form['nombre']
    direccion = request.form['direccion']
    telefono = request.form['telefono']
    
    conexion = conectar_bd()
    cursor = conexion.cursor()
    consulta = """
    UPDATE Proveedor
    SET nombre = %s, direccion = %s, telefono = %s
    WHERE idProveedor = %s
    """
    cursor.execute(consulta, (nombre, direccion, telefono, id_proveedor))
    conexion.commit()
    conexion.close()
    return redirect(url_for('proveedores'))

@app.route('/eliminar_proveedor/<int:id_proveedor>', methods=['POST'])
def eliminar_proveedor(id_proveedor):
    try:
        conexion = conectar_bd()
        cursor = conexion.cursor()

        # Verificar si el proveedor tiene productos asociados
        cursor.execute("SELECT COUNT(*) FROM ProductoProveedor WHERE idProveedor = %s", (id_proveedor,))
        relaciones = cursor.fetchone()[0]

        if relaciones > 0:
            return f"No se puede eliminar el proveedor con ID {id_proveedor} porque tiene productos asociados.", 400

        # Eliminar el proveedor
        cursor.execute("DELETE FROM Proveedor WHERE idProveedor = %s", (id_proveedor,))
        conexion.commit()
        conexion.close()

        return redirect(url_for('proveedores'))
    except Exception as e:
        return f"Error al eliminar el proveedor: {str(e)}", 500



# Ver Proveedor
@app.route('/ver_proveedor/<int:id_proveedor>', methods=['GET'])
def ver_proveedor(id_proveedor):
    conexion = conectar_bd()
    cursor = conexion.cursor()
    
    # Consulta para obtener los datos del proveedor por ID
    cursor.execute("SELECT * FROM Proveedor WHERE idProveedor = %s", (id_proveedor,))
    proveedor_data = cursor.fetchone()
    conexion.close()

    # Manejo del caso en que no se encuentre el proveedor
    if not proveedor_data:
        return f"No se encontró un proveedor con ID {id_proveedor}", 404

    # Convertir los datos en un diccionario
    proveedor = {
        'idProveedor': proveedor_data[0],
        'nombre': proveedor_data[1],
        'direccion': proveedor_data[2],
        'telefono': proveedor_data[3]
    }

    return render_template('ver_proveedor.html', proveedor=proveedor)


@app.route('/compras', methods=['GET', 'POST'])
def compras():
    if request.method == 'POST':
        id_producto = int(request.form['id_producto'])
        cantidad = int(request.form['cantidad'])

        conexion = conectar_bd()
        cursor = conexion.cursor()

        # Actualizar el inventario
        cursor.execute("""
            UPDATE Producto SET cantidadStock = cantidadStock + %s WHERE idProducto = %s
        """, (cantidad, id_producto))

        conexion.commit()
        conexion.close()
        return redirect(url_for('compras'))

    conexion = conectar_bd()
    cursor = conexion.cursor()
    cursor.execute("SELECT idProducto, nombre, cantidadStock FROM Producto")
    productos = cursor.fetchall()
    conexion.close()
    return render_template('compras.html', productos=productos)

if __name__ == '__main__':
    app.run(debug=True)
